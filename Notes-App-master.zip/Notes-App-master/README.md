# Notes-App
This is the android app built using java and made in Android Studio. This app is made by taking into consideration of the "Android Architecture Components". This app mainly focuses on the CRUD operations i.e, this app will let you able to add, read, update, and delete the notes by using the Room database.

# Screen Recording

https://user-images.githubusercontent.com/65127291/105842988-09c1ea00-5ffd-11eb-824c-4be9342847d0.mp4
